# [ADDED v1.0] Routers exportados para importación centralizada
from routers import auth, vocabulary, exercises, metrics
