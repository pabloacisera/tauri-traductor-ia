// [ADDED v3.0] Módulo de vocabulario — bookmark de palabras desde el modal de análisis
const API_BASE = 'http://localhost:8000';

function authHeaders() {
  const h = { 'Content-Type': 'application/json' };
  const token = localStorage.getItem('contextia_token');
  if (token) {
    h['Authorization'] = `Bearer ${token}`;
  }
  return h;
}

// [ADDED v3.0] Inyectar botones bookmark cuando aparece el modal de análisis
function injectBookmarkButtons() {
  const modal = document.getElementById('linguistic-modal');
  if (!modal) return;

  const vocabContainers = modal.querySelectorAll('.section-content');
  vocabContainers.forEach(container => {
    const tags = container.querySelectorAll('.vocab-tag');
    tags.forEach(tag => {
      if (tag.parentElement.querySelector('.vocab-bookmark')) return;

      const word = tag.textContent.trim();
      const levelSmall = tag.parentElement.querySelector('small');
      let level = 'B1';
      let definition = '';
      if (levelSmall) {
        const text = levelSmall.textContent;
        const match = text.match(/\[(.*?)\]\s*-\s*(.*)/);
        if (match) {
          level = match[1];
          definition = match[2];
        }
      }

      const btn = document.createElement('button');
      btn.className = 'vocab-bookmark';
      btn.dataset.word = word;
      btn.dataset.level = level;
      btn.dataset.definition = definition;
      btn.title = 'Guardar para practicar';
      btn.innerHTML = `
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
          <path d="M19 21l-7-5-7 5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z"></path>
        </svg>
      `;
      tag.parentElement.appendChild(btn);
    });
  });
}

// [ADDED v3.0] MutationObserver para detectar cuando se renderiza el modal de análisis
const vocabObserver = new MutationObserver((mutations) => {
  for (const m of mutations) {
    for (const node of m.addedNodes) {
      if (node.nodeType === 1 && node.id === 'linguistic-modal-overlay') {
        // Esperar a que el contenido se renderice
        setTimeout(injectBookmarkButtons, 100);
        setTimeout(injectBookmarkButtons, 600);
      }
    }
  }
});
vocabObserver.observe(document.body, { childList: true, subtree: true });

// [ADDED v3.0] Delegación de eventos para clicks en bookmark
document.body.addEventListener('click', async (e) => {
  const btn = e.target.closest('.vocab-bookmark');
  if (!btn) return;
  e.preventDefault();

  const token = localStorage.getItem('contextia_token');
  if (!token) {
    window.openAuthModal(() => {
      // Reintentar guardado después de login
      saveWord(btn);
    }, 'Guardá palabras para practicarlas después');
    return;
  }

  await saveWord(btn);
});

async function saveWord(btn) {
  if (btn.classList.contains('saved')) return;

  try {
    const res = await fetch(`${API_BASE}/vocabulary/save`, {
      method: 'POST',
      headers: authHeaders(),
      body: JSON.stringify({
        word: btn.dataset.word,
        definition: btn.dataset.definition || '',
        level: btn.dataset.level || 'B1',
        target_lang: window.currentTranslationLang || 'en'
      })
    });
    const data = await res.json();
    if (res.ok) {
      btn.classList.add('saved');
      btn.title = 'Guardado';
      // [ADDED v3.0] Notificar que se guardó una palabra (para habilitar práctica)
      window.dispatchEvent(new CustomEvent('contextia:vocabularysaved'));
    }
  } catch (err) {
    // Silencioso — no bloquear la UI
  }
}
